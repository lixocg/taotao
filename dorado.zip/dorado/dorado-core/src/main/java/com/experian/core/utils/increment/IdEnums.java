package com.experian.core.utils.increment;

public enum IdEnums {
	LITIGATION_DATA("litigation_key","诉讼详情主键");
	IdEnums(String key,String name){
		this.key=key;
		this.name=name;
	}
	private String key;
	private String name;
	public String getKey() {
		return key;
	}
	public String getName() {
		return name;
	}
	
}

package com.experian.core.enums;

/**
 * 服务枚举...服务名称起名规则：取项目名
 * 
 * @author lixiongcheng
 *
 */
public enum Srv {
	/**
	 * 基础信息服务
	 */
	baseinfo("dorado-daas-baseinfo"),

	/**
	 * 诉讼服务
	 */
	litigation("dorado-daas-litigation");

	private String srvName;

	Srv(String srvName) {
		this.srvName = srvName;
	}

	public String getSrvName() {
		return this.srvName;
	}
}

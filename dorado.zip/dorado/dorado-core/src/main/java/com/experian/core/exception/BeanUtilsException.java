package com.experian.core.exception;

@SuppressWarnings("serial")
public class BeanUtilsException extends RuntimeException{

  public BeanUtilsException(Throwable e){
    super(e);
  }

}

package com.experian.dto.pojo.litigation;

public class ResultPojo {
	private String code;
	private String data;
	
	public ResultPojo(String code, String data) {
		super();
		this.code = code;
		this.data = data;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	
}

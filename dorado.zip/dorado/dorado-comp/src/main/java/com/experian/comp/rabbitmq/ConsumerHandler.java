package com.experian.comp.rabbitmq;

public interface ConsumerHandler {
	void handle(String msg);
}

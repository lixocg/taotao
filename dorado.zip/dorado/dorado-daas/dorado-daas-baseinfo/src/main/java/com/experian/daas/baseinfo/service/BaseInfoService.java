package com.experian.daas.baseinfo.service;

public interface BaseInfoService {
	/**
	 * 通过公司名称匹配sbdnum
	 * 
	 * @param corpName
	 *            公司名称
	 * @return
	 * @throws Exception 
	 */
	String match(String corpName) throws Exception;
}

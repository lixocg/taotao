package com.experian.daas.litigation.dao;

import java.util.List;

import com.experian.dto.entity.litigation.LitigationErrorCrawledData;

public interface LitigationErrorCrawledDataDao {
    int deleteByPrimaryKey(String id);

    int insert(LitigationErrorCrawledData record);

    LitigationErrorCrawledData selectByPrimaryKey(String id);

    List<LitigationErrorCrawledData> selectAll();

    int updateByPrimaryKey(LitigationErrorCrawledData record);
}
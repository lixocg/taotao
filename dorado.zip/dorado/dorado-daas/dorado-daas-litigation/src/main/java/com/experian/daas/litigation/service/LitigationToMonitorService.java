package com.experian.daas.litigation.service;

import com.experian.dto.pojo.litigation.LitigationAPIPojo;

/**
 * 诉讼数据传给监测模块
 * @author e00769a
 *
 */
public interface LitigationToMonitorService {

	String transLitigationTo(LitigationAPIPojo litigation);

}

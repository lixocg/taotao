package com.experian.daas.litigation.service;

import com.experian.dto.entity.litigation.LitigationCaseCategory;

public interface LitigationService {
	LitigationCaseCategory getLitigationCaseCategory(Integer id);

}

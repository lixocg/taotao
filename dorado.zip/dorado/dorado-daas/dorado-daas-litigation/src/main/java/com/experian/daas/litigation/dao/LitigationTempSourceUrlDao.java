package com.experian.daas.litigation.dao;

import java.util.List;

import com.experian.dto.entity.litigation.LitigationTempSourceUrl;

public interface LitigationTempSourceUrlDao {
    int deleteByPrimaryKey(String id);

    int insert(LitigationTempSourceUrl record);

    LitigationTempSourceUrl selectByPrimaryKey(String id);

    List<LitigationTempSourceUrl> selectAll();

    int updateByPrimaryKey(LitigationTempSourceUrl record);
}
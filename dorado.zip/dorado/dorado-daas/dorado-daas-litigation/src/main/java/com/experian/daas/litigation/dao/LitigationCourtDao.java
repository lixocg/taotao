package com.experian.daas.litigation.dao;

import java.util.List;

import com.experian.dto.entity.litigation.LitigationCourt;

public interface LitigationCourtDao {
    int deleteByPrimaryKey(Integer id);

    int insert(LitigationCourt record);

    LitigationCourt selectByPrimaryKey(Integer id);

    List<LitigationCourt> selectAll();

    int updateByPrimaryKey(LitigationCourt record);
}